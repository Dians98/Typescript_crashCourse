abstract class People {


   displayDate(){

        console.log("some data");


    }


}

class Kids extends People{}




let KidsClass = new Kids;

KidsClass.displayDate();
