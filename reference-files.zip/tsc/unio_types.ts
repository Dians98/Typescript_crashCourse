let unionType: number | string;

unionType = "String";

unionType = 34;

unionType = false;


