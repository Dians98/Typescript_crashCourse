function displayData<TYPE>(someData: TYPE){

    let someOtherData: TYPE;

    return someData;

}

console.log(displayData(53442535));



// function displayData2(someData: number){
//
//     return someData;
//
// }
//
//
// function displayData3(someData: string){
//
//     return someData;
//
// }




