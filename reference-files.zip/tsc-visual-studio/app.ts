class Example{


    name:string;


}