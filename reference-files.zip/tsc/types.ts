let car: string;

let engine: number;

let isFast: boolean;


car = "BMW";

engine = 5.4;

isFast = true;


class Car {

    brand: string;



}






