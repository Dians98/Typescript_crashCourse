var Example = (function () {
    function Example() {
    }
    return Example;
}());
