function cal(val1, val2) {
    var total = val1 + val2;
    return total;
}
cal(2, 2);
//# sourceMappingURL=types3.js.map