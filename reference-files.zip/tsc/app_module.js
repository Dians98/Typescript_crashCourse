"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function displaySomeData(value) {
    return value;
}
exports.displaySomeData = displaySomeData;
//# sourceMappingURL=app_module.js.map