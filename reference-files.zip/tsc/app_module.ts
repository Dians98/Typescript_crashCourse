export function displaySomeData(value:string){

    return value;

}
