class Example {

    name: string;


}
