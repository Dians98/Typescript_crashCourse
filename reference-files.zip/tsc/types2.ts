// let name: any;
//
// name = 12;
//
// name = "Edwin Diaz";




// let cars:  = ["Toyota", "BMW", "Mercedes"];
//
// cars = ["nissan"]



//
// let cars: any[] = ["Toyota", "BMW", "Mercedes"];
//
// cars = ["nissan"]

//
// let cars: any = ["Toyota", "BMW", "Mercedes"];
//
// cars = "nissan"

//


// let cars: number[]  = [2,45,7,865,657];
//
// cars = [3242]


