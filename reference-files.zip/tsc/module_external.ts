
    export const name = "Mariasssss";

    export function displayData(value: string){

        return value;

    }



