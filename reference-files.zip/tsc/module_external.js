"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.name = "Mariasssss";
function displayData(value) {
    return value;
}
exports.displayData = displayData;
//# sourceMappingURL=module_external.js.map