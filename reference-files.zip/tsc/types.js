var car;
var engine;
var isFast;
car = "BMW";
engine = 5.4;
isFast = true;
var Car = (function () {
    function Car() {
    }
    return Car;
}());
//# sourceMappingURL=types.js.map