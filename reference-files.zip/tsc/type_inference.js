/**
 * Created by edwin on 5/24/17.
 */
var car = {
    brand: "BWM",
    engine: 3.4,
    run: function () {
        console.log("driving at 100 miles an hour");
    }
};
var house = "house";
// house = 123;
//# sourceMappingURL=type_inference.js.map