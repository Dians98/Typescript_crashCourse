"use strict";
//import Object = require("./module_external");
Object.defineProperty(exports, "__esModule", { value: true });
var module_external_1 = require("./module_external");
console.log(module_external_1.displayData("Hey this is cool dudesssss"));
console.log(module_external_1.name);
//# sourceMappingURL=module_runner.js.map