"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var app_module_1 = require("./app_module");
console.log(app_module_1.displaySomeData("I just got changed in typescript and then compiled"));
//# sourceMappingURL=app.js.map