function displayData(someData) {
    var someOtherData;
    return someData;
}
console.log(displayData(53442535));
// function displayData2(someData: number){
//
//     return someData;
//
// }
//
//
// function displayData3(someData: string){
//
//     return someData;
//
// }
//# sourceMappingURL=generics.js.map