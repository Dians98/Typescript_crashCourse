var vehicle = {
    brand: "Mercedes",
    engineType: 4.6
};
vehicle.brand = "";
//# sourceMappingURL=object_types.js.map