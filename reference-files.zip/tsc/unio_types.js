var unionType;
unionType = "String";
unionType = 34;
unionType = false;
//# sourceMappingURL=unio_types.js.map