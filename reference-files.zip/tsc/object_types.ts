let vehicle: {brand: string, engineType: number} = {

    brand: "Mercedes",
    engineType: 4.6

}


vehicle.brand = "";



