//import Object = require("./module_external");

import {name as MyName, displayData, } from "./module_external";


console.log(displayData("Hey this is cool dudesssss"));
console.log(MyName);