var Example = (function () {
    function Example() {
    }
    return Example;
}());
//# sourceMappingURL=example2.js.map