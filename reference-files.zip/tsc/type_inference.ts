/**
 * Created by edwin on 5/24/17.
 */

let car = {

    brand: "BWM",
    engine: 3.4,
    run: function(){

        console.log("driving at 100 miles an hour")


    }

};

let house = "house";

// house = 123;







