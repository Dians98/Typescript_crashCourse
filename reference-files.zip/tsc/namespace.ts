///<reference path="module1.ts" />


import thisSpace = myNameSpace.displayData;



console.log(thisSpace("Hello this Edwin Diaz"));
