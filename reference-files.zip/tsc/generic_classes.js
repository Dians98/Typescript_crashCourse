var array1 = [1, 45654, 5463546];
var array2 = ["sadf", "dsaf"];
var objectGenericsCLass = (function () {
    function objectGenericsCLass(value1, value2) {
        this.value1 = value1;
        this.value2 = value2;
    }
    return objectGenericsCLass;
}());
var object1 = new objectGenericsCLass("asdfdsa", "sadfas");
var object2 = new objectGenericsCLass(true, "asfdsa");
//# sourceMappingURL=generic_classes.js.map