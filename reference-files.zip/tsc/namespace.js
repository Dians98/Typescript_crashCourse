///<reference path="module1.ts" />
var thisSpace = myNameSpace.displayData;
console.log(thisSpace("Hello this Edwin Diaz"));
//# sourceMappingURL=namespace.js.map