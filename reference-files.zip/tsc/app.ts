import {displaySomeData} from "./app_module"


console.log(displaySomeData("I just got changed in typescript and then compiled"));
