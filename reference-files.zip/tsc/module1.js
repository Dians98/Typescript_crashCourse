var myNameSpace;
(function (myNameSpace) {
    myNameSpace.name = "Mariasssss";
    function displayData(value) {
        return value;
    }
    myNameSpace.displayData = displayData;
})(myNameSpace || (myNameSpace = {}));
//# sourceMappingURL=module1.js.map